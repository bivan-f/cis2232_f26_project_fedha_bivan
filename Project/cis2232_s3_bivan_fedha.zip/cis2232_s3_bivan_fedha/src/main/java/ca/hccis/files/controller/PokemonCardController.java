package ca.hccis.files.controller;

import ca.hccis.files.entity.PokemonCard;
import ca.hccis.files.repository.PokemonCardRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/pokemon")
public class PokemonCardController {

    @Autowired
    private PokemonCardRepository repository;

    @GetMapping("")
    public String listCards(Model model) {

        model.addAttribute(
                "cards",
                repository.findAll());

        return "pokemon/list";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {

        model.addAttribute(
                "pokemonCard",
                new PokemonCard());

        return "pokemon/add";
    }

    @PostMapping("/add")
    public String addCard(
            @Valid @ModelAttribute PokemonCard pokemonCard,
            BindingResult result) {

        if (result.hasErrors()) {
            return "pokemon/add";
        }

        repository.save(pokemonCard);

        return "redirect:/pokemon";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(
            @PathVariable Integer id,
            Model model) {

        PokemonCard card =
                repository.findById(id).orElse(null);

        model.addAttribute(
                "pokemonCard",
                card);

        return "pokemon/edit";
    }

    @PostMapping("/update")
    public String updateCard(
            @Valid @ModelAttribute PokemonCard pokemonCard,
            BindingResult result) {

        if (result.hasErrors()) {
            return "pokemon/edit";
        }

        repository.save(pokemonCard);

        return "redirect:/pokemon";
    }

    @GetMapping("/delete/{id}")
    public String deleteCard(
            @PathVariable Integer id) {

        repository.deleteById(id);

        return "redirect:/pokemon";
    }
}