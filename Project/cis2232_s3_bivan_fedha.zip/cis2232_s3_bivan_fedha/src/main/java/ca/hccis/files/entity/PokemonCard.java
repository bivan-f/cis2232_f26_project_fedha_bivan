package ca.hccis.files.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

@Entity
@Table(name = "pokemon_cards")
public class PokemonCard {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotBlank(message = "Card name is required")
    private String cardName;

    @NotBlank(message = "Card type is required")
    private String cardType;

    @Min(value = 1, message = "Hit Points must be greater than 0")
    private int cardHitPoints;

    @NotBlank(message = "Attack name is required")
    private String cardAttackName;

    @Min(value = 0, message = "Attack Damage cannot be negative")
    private int cardAttackDamage;

    private int cardAttackCost;

    private int cardStage;

    private int cardRetreatCost;

    public PokemonCard() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCardName() {
        return cardName;
    }

    public void setCardName(String cardName) {
        this.cardName = cardName;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public int getCardHitPoints() {
        return cardHitPoints;
    }

    public void setCardHitPoints(int cardHitPoints) {
        this.cardHitPoints = cardHitPoints;
    }

    public String getCardAttackName() {
        return cardAttackName;
    }

    public void setCardAttackName(String cardAttackName) {
        this.cardAttackName = cardAttackName;
    }

    public int getCardAttackDamage() {
        return cardAttackDamage;
    }

    public void setCardAttackDamage(int cardAttackDamage) {
        this.cardAttackDamage = cardAttackDamage;
    }

    public int getCardAttackCost() {
        return cardAttackCost;
    }

    public void setCardAttackCost(int cardAttackCost) {
        this.cardAttackCost = cardAttackCost;
    }

    public int getCardStage() {
        return cardStage;
    }

    public void setCardStage(int cardStage) {
        this.cardStage = cardStage;
    }

    public int getCardRetreatCost() {
        return cardRetreatCost;
    }

    public void setCardRetreatCost(int cardRetreatCost) {
        this.cardRetreatCost = cardRetreatCost;
    }
}