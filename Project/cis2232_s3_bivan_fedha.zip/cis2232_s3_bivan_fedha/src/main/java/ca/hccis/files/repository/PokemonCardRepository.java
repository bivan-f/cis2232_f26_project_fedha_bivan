package ca.hccis.files.repository;

import ca.hccis.files.entity.PokemonCard;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PokemonCardRepository
        extends JpaRepository<PokemonCard, Integer> {

}